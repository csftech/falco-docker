#pragma once

#define PROBE_VERSION "0.9.0-1"

#define PROBE_NAME "falco-probe"

#define PROBE_DEVICE_NAME "falco"
